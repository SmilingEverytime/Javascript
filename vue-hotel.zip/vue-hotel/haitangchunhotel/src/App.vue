<template>
  <transition name="fade">
    <div id="app">
      <router-view/>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'App'
}

</script>
<style>


</style>
