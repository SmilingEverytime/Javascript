<template>
  <section id="story" class="description_content">
    <div class="text-content container">
      <div class="col-md-6">
        <h1>Feature Food</h1>
        <div class="fa fa-cutlery fa-2x"></div>
        <p class="desc-text">海棠春自助餐厅. 位于海棠春酒店一楼，汇集各式中西美食，特别精心制作陕西及汉中风味的美味佳肴。供应自助早餐、午餐及主题晚餐，中西合璧，时尚简约。 徽韵轩堂吧. 位于饭店一楼大厅内，舒适、典雅的环境，一览环湖美景，为您提供香茗热饮、鸡尾酒，各式精美点心及特色茶饮套餐，让您体验秦巴山川的同时倍感休闲舒适。
        </p>
      </div>
      <div class="col-md-6">
        <div class="img-section">
          <img src="/static/images/about.jpg" width="250" height="220">
          <img src="/static/images/about1.jpg" width="250" height="220">
          <div class="img-section-space"></div>
          <img src="/static/images/about2.jpg" width="250" height="220">
          <img src="/static/images/about3.jpg" width="250" height="220">
        </div>
      </div>
    </div>
  </section>
</template>
<script>
// import 'font-awesome/scss/font-awesome.scss'

</script>
