<template>
  <div class="news">
    <div class="conmenu">
      <p>海棠春酒店</p>
      <p>酒店新闻</p>
    </div>
  </div>
</template>
