<template>
  <div style="background-image: url(./../../static/images/foot.png)">
  </div>
</template>
<style type="text/css">
div {
  width: 100%;
  height: 400px;
}

</style>
