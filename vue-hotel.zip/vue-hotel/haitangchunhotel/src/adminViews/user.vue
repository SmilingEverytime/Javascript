<template>
	<div>
		
{{id}}

	</div>
</template>
<script type="text/javascript">
export default {
  data() {
    return {
      id: "eee"
    }
  }
}

</script>
